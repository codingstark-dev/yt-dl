//! enter your site details here

// import { env } from "process"

let SiteDetails = {
    "googleAnalytic": "UA-107325278-5",
    'title': "YutMp3.com",
    'description': 'YutMp3.com',
    'website': process.env.NODE_ENV == 'production' ? 'https://yutmp3.com' : 'http://localhost:3000',
    'website_name': 'YutMp3',
    "domain_extension": "Com",
    "email": "admin@yutmp3.com"
    // "api": "https://dummyapisds.herokuapp.com"+"/api/",
    // "pub_id": "ca-pub-XXXXXXXXXXXXXXXX",
    // "slot1": "",
    // "slot2": "",


}





export { SiteDetails }



// </p><h2>Frequently Asked Questions : -&nbsp;</h2 > <p><strong>Is This Online Tool Free Or Paid ? </strong></p > <p>YutMp3.Com's Youtube to mp3 converter tool is completely free, there is no paid option in this online tool.</p><p><strong>Is there any Registration or Sign-in Required?</strong></p><p>No, Users no need to sign in or sign-up. it's completely open - source to convert and download.< /p><p><strong>Is it safe to use yutmp3.com?</strong > </p><p>Yes, it's. YutMp3.com is the safest online youtube to mp3 converter tool. This tool doesn't store or capture any user Personal, and BrowserData.</p > <p><strong>Which is the best website for online youtube to mp3 converter ? </strong></p > <p>https ://yutmp3.com is the best and faster online website for convert and download youtube videos into an Mp3 audio file.</p><p><strong>Can we convert and download other website videos like Facebook, Instagram?</strong></p><p>No, currently this website doesn't havethat feature to download other website videos except youtube. In the feature updates, other website conversions will be updated.<p><p><strong>What is YutMp3.com?</strong></p><p>YutMp3.com is a free website, it allows visitors to convert and download youtube to mp3 and youtube to mp4.</p><p><strong>What type of audio formates available here to download?</strong></p><p>Right now YutMp3.com provides different types of audio bitrates like 320 Kbps, 256 Kbps, 192 Kbps, 128 Kbps, and 64 Kbps.</p><p><strong>Can I access yutmp3's Youtubemp3 converter in my Country?</strong></p><p>Yes, anyone can access the yutmp3.com website. it is available in any country around the globe.</p><p><strong>Are there any video length limitations to convert youtube to mp3?</strong></p><p>No, there is no length limit to convert and download. any video available on youtube can be converted to yutmp3.com. Video length does notmatter to download.</p><p><strong>What Type of Devices supports using youtube to mp3?</strong></p><p>Yes, Any device could be compatible Like All Smart Phones, Computers, Ipads to convert and download youtube to mp3. Just you need InternetConnection. Here are some examples. All android and IOS mobiles, Apple and Windows, and Linux Computers. Ipads also support. Symbian devices andJava mobiles also support yutmp3.com.</p><p><strong>How to Convert and Download Youtube to Mp3 320 Kbps?</strong></p><p>Yutmp3.com website provides a feature to get youtube videos into 320 Kbps High-Quality mp3 format.</p><p><strong>Can We convert Youtube videos to Mp4 and other video formats?</strong></p><p>Yes, you may convert and download youtube videos into video formats. Mp4, 3GP, MKV, 1080P, 720P, 360P quality currently available. SoonYoutube to 4K and Youtube to 8K available.</p><p><strong>How to Find YutMp3.com website in Google?</strong></p><p>You can use the following keywords to following keywords to search the yutmp3 web site. Yutmp3.com, YutMp3, Yutmp3 Youtube to mp3 Convert,Youtube to Mp3, YoutubeMp3 Convert, Online youtube to mp3 convert, youtube to 256 kbps mp3, youtube to 320 kbps mp3, youtube to 128 kbps mp3,youtube to 64 Kbps Mp3, youtube to WAV convert,Online youtube to mp3 audio download, youtubemp3 converter online, best online tool for youtubeto mp3 320 kbps.</p><strong>Final words about YutMp3 Web Site</strong><p>YutMp3.com is just a tool that allows visitors to convert and download youtube videos. This website does not ability to store or uploadfiles. All the converted files downloaded from external servers. Thank you for using Yut mp3.</p></div>